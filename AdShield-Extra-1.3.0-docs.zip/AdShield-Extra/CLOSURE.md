# AdShield Extra — Project Closure

This document has two parts: a record of every real bug found and fixed
during this project (not feature work — genuine defects, in the sense
of "the code did something other than what it was supposed to do"),
and a porting guide for anyone who wants to bring the Privacy & Security
redesign back into the parent uBlock-Stripped-Dynamic extension.

---

## Part 1 — Bugs found and fixed

Each entry: what was actually wrong, why it happened, and exactly how
it was fixed. Ordered roughly by when they were found. Full detail and
surrounding context for every one of these is also in `CHANGELOG.md`
under the version noted.

### 1. Stale license/privacy claims (v1.1.1)

**What was wrong:** `LICENSE.txt`'s preamble claimed a bundled
"top-1M/tracker-domain crossref" that had actually been removed from
the codebase already (still true today — that one was never brought
back). It also claimed a bundled "DuckDuckGo Tracker Radar dataset" —
also false at the time, though this one has its own short history: the
dataset genuinely was gone at v1.1.1, so the claim was correctly
removed then; it was later deliberately re-added as a real feature in
v1.1.4 (the "known tracker" column — a feature port, not a bug fix),
at which point the claim was correctly restored too. Net effect,
today: accurate either way you look at it, then or now.
`THIRD_PARTY_LICENSES.md` was missing four libraries that ship their
own `LICENSE` file in the tree (`lib/csstree/`, `lib/codemirror/`,
`lib/regexanalyzer/`, `css/fonts/Inter/`) — never documented at all.
`PRIVACY_POLICY.md` claimed cosmetic/scriptlet rules were applied via
Chrome's "User Scripts API" using "the filter text you entered in the
extension's own filter editor" — both false: that API was dropped
before this fork even started, and the filter editor doesn't exist in
this variant.

**How found:** A dedicated license/permission audit, cross-referencing
every file that ships a `LICENSE` in the tree against what
`THIRD_PARTY_LICENSES.md` actually documents, and reading the current
runtime code path rather than trusting the existing prose.

**Fix:** Corrected all three files to match the actual bundled content
and mechanism at each point in time — including the DDG Tracker Radar
correction going the other way again in v1.1.4. Confirmed still
accurate as of this document: all three currently document the Tracker
Radar dataset as bundled.

### 2. Factual error about Chrome's `browsingData` API (v1.1.1)

**What was wrong:** Claimed `siteSettings` was "Chrome's own name for
per-site permissions" and that it was a real `chrome.browsingData`
data type being deliberately left unset. It isn't a real property of
that API at all.

**How found:** Verified directly against Chrome's current,
authoritative API reference before finalizing the claim (not assumed
from memory) — the property list doesn't include it.

**Fix:** `js/core/history-cleaner.js`'s header comment corrected to
state the real reason site permissions are never touched: there is no
corresponding `chrome.browsingData` data type at all, not that one is
being deliberately skipped.

### 3. Accidental self-closing CSS comment (v1.1.5)

**What was wrong:** A comment written during the Privacy & Security
redesign contained the literal text `.security-column-head*/.security-row`
— the `*/` inside that path fragment closed the CSS comment early,
leaving the rest of the comment's text as raw, invalid CSS.

**How found:** The check suite's CSS structural validation (comment
brace-balance check) failed after the edit.

**Fix:** Reworded the comment to `.security-column-head / .security-row`
(spaces around each `/`), removing the accidental `*/` sequence.
`dashboard/settings.css`.

### 4. Risk indicator mismatch between Privacy Inspector and Manage Custom Rules (v1.1.8)

**What was wrong:** The same rule could show a different risk badge
depending on which panel displayed it. Root cause: Privacy Inspector
had its own `CATEGORY_RISK_OVERRIDE` for the `beacon`/`legit-signals`
categories (forcing RISK_HIGH, based on confirmed real-site breakage
evidence — bnr.nl, nos.nl), but `js/data/scriptlet-rule-labels.js`'s
`RULE_INFO` — the table Manage Custom Rules relies on via
`getScriptletRuleRisk()` — had no matching entry for either category
at all. `findRuleInfo()` returned `null` for these two, so Manage
Custom Rules silently fell through to RISK_UNKNOWN for the exact same
rule Privacy Inspector was showing as RISK_HIGH.

**How found:** Explicit request to unify the two panels' risk display,
followed by tracing both panels' actual risk-computation call sites
rather than assuming they already shared one code path.

**Fix:** Added the two missing entries (`navigator.sendBeacon`, and
the `hardwareConcurrency`/`deviceMemory`/`maxTouchPoints`/`connection`/
`getGamepads` group) directly to `RULE_INFO` in
`js/data/scriptlet-rule-labels.js`, with the same RISK_HIGH level and
sourced reasoning Privacy Inspector's override already had. Then
deleted `CATEGORY_RISK_OVERRIDE` from `privacy/privacy-inspector.js`
entirely — `getScriptletRuleRisk()` alone is now the single source of
truth for both panels, not two separately-maintained tables that
merely happened to agree.

### 5. First-party sites incorrectly blocked by the SCP familiar-TLD exemption (v1.1.9)

**What was wrong:** While building the SCP (Sandboxed Content
Permissions) feature, the familiar-TLD "safe region" exemption rule
was about to reuse the existing `buildTldAllowRules()` helper as-is —
but that helper hardcodes `domainType: 'thirdParty'`, while the SCP
block rule itself applies with no `domainType` restriction (both
first- and third-party, since visiting an unfamiliar site directly
should also have its own permissions restricted). Reusing the
third-party-only exemption unmodified would have left a familiar-TLD
site's own first-party permission requests incorrectly blocked when
visited directly.

**How found:** Traced the exemption's actual match scope against the
block rule's scope before wiring them together, rather than assuming
the existing helper's defaults were still correct for a new use case.

**Fix:** Added a `domainType` parameter to `buildTldAllowRules()`
(default `'thirdParty'`, preserving the two existing callers'
behavior); the SCP exemption passes `null` to omit the restriction
entirely. `js/core/worry-free-familiar-tld-manager.js`.

### 6. Duplicate content-script registration ID (v1.1.9)

**What was wrong:** The new `blockScpFingerprint` entry was going to
reuse `id: 'sec-adult-fingerprint'` — the same registration ID as the
existing `blockAdultFingerprinting` entry, which also uses that
scriptlet file. Chrome's `registerContentScripts()` requires unique
IDs, and both entries can be simultaneously active.

**How found:** Cross-checked the two entries' IDs against each other
before finalizing the new one, since they share an underlying script
file.

**Fix:** Added a `scriptFile` field to the directive-building loop in
`js/core/compiled-filters.js`, defaulting to `id` (matching every
other entry's existing behavior) but overridable — the new entry uses
`id: 'sec-scp-fingerprint'` with `scriptFile: 'sec-adult-fingerprint'`,
giving it a unique registration ID while still loading the shared
script.

### 7. Circular import risk (v1.1.9)

**What was wrong:** The natural place to re-register security
scriptlets after a familiar-TLD-list change was directly inside
`worry-free-familiar-tld-manager.js`, right after its DNR rules
update. Importing `registerSecurityContentScripts` there would have
created `scripting-manager.js → compiled-filters.js →
worry-free-familiar-tld-manager.js → scripting-manager.js` — a real
cycle, since `compiled-filters.js` had just been given its own new
import of the familiar-TLD manager for the same feature.

**How found:** Traced the full import graph before adding the new
import, rather than adding it and letting the check suite catch it
after the fact.

**Fix:** Moved the re-registration call to the routes layer
(`js/workflow/ruleset-routes.js`'s `handleSetWorryFreeFamiliarTlds`/
`handleRestoreWorryFreeFamiliarTlds`), which can safely import both
sides without a cycle. Confirmed clean afterward by the check suite's
own circular-dependency check, not just assumed.

### 8. Three settings that could never activate at all (v1.2.2)

**What was wrong — the most significant bug of this project.**
`blockSuspicious3pLinks`, `blockScpPrivacy`, and `blockScpSecurity` all
gate on `isWorryFreeActive && securityConfig[key] !== false` (a
"genuine opt-out" scheme — checking the box means "allow this to
auto-apply during Worry-free"; unchecking it means "never apply, even
during Worry-free"). Their stored **defaults were literally `false`**
— which under this exact gating logic *is* the opt-out signal, not
"off until Worry-free." The practical effect: these three protections
could never turn on at all, under any circumstance, including during
an active Worry-free session — the precise opposite of their own group
heading, "enabled by default in Worry-free mode."

**How found:** A direct user question — "are all settings by default
enabled?" — prompted checking every setting's actual stored default
against its actual gating logic, rather than against what the
dashboard checkbox merely displayed as checked/unchecked.

**Fix:** Changed all three defaults to `true` in `js/data/config.js`
(`true` is what "not yet opted out" looks like under this gating
scheme). `blockObfuscatedEval`/`blockScpFingerprint`, which already
had `true`, were unaffected — they'd been correct all along.

### 9. Two settings using the wrong on/off mechanism entirely (v1.2.3)

**What was wrong:** `blockAdultNoEval`/`blockAdultFingerprinting` were
moved into the "enabled by default in Worry-free mode" group during
the redesign, but their underlying mechanism (`worryFreeOverride`) was
never changed to match: checking the box made them always-active
regardless of Worry-free state, and — separately — Worry-free forced
them on even when unchecked. Neither half of that matches "only during
Worry-free, unchecking opts out."

**How found:** Explicit clarification from the person ("No it is only
applied when worry-free is on, that is why I moved them!") after an
earlier miscommunication about the correct tooltip wording surfaced
the mechanism mismatch underneath it.

**Fix:** Converted both entries from `worryFreeOverride` to
`worryFreeGatedOptOut` in `js/core/compiled-filters.js`, and — per the
same root cause as bug #8 — changed their base defaults from `false`
to `true` in `js/data/config.js`, since the same `!== false` gating
logic applies here too.

### 10. Allow list entries permanently stuck not taking effect (v1.2.6)

**What was wrong — the second most significant bug.**
`handleSiteModeSetAll()` (the Allow list editor's bulk-save handler)
only wrote the actual DNR exemption rule for hostnames whose mode
differed from the currently-stored `'siteModes'` — the *same* storage
the diff compared against. If a domain's real filtering state
(`filteringModeDetails`, a separate storage key) ever desynced from
`'siteModes'` at any point in the past — for example, an entry saved
before an earlier version of this same function's own fix existed —
every later save saw "no change" for that hostname and never
re-synced it. The desync became permanently stuck: the dashboard
editor correctly showed the domain as allowlisted, but the toolbar
icon and actual request-blocking behavior never reflected it, because
the *stored data* carried the bug forward even after the code itself
had been fixed once already.

**How found:** Reported directly by the person ("the Allow list does
not work anymore... icon does not turn grey and shows blocked items
for a domain already on the allowlist"), with an explicit instruction
to check the CHANGELOG for prior related issues first. That surfaced
`## 9.2.1`'s own allowlist regression (a different bug, DNR
session-rules not clearing on auto-update) — ruled out by confirming
its fix was still intact — before tracing the actual write path found
this second, distinct bug in the same feature.

**Fix, two parts, in `js/workflow/mode-routes.js` and
`js/workflow/background.js`:**
1. `handleSiteModeSetAll()` now reconciles the full union of old+new
   hostnames unconditionally on every save, not gated on a diff —
   every save is now self-healing. Deliberately reuses the existing,
   well-tested `setFilteringMode()`/`applyFilteringMode()`
   per-hostname logic rather than rebuilding the `none`/`basic` Sets
   directly, to avoid risking a *new* bug in that function's
   hierarchy/subtree-pruning logic.
2. A one-time step added to `runVersionMigration()` forces this same
   reconciliation immediately on the next version bump, so an
   already-desynced install self-heals without the person needing to
   manually re-touch every affected entry in the dashboard editor.

### 11. Cookie-clicker content scripts never re-registered after a site-mode toggle (found via cross-check against uBlock-Stripped-Dynamic's own porting work)

**What was wrong:** `applySiteMode()` (single-hostname toggle) and
`handleSiteModeSetAll()` (Allow list bulk save) both correctly
re-registered `registerContentScripts()` and
`registerSecurityContentScripts()` after a site-mode change, but never
`registerCookieClickerContentScripts()` or
`registerCookieClickerAutoDenyContentScripts()` — a third and fourth
independently site-mode-scoped content-script group (both compute
their own `matches`/`excludeMatches` via the same
`buildSiteModeMatchScope()` call the other two use). A site toggled
off then back on kept using whichever scope was in effect the last
time cookie-clicker happened to be registered (e.g. extension
startup) — previously-working cookie-consent-clicker rules for that
site would silently stop firing, with the rules themselves still
correctly present in storage.

**How found:** Not found independently — a person who ported this
project's Privacy & Security redesign into the parent
uBlock-Stripped-Dynamic project found and fixed this same bug there,
then asked whether it also existed here. Checked directly rather than
assumed either way: traced both cookie-clicker registration functions
and confirmed both do compute the site-mode scope, then confirmed
neither call site included them.

**Fix:** Added `registerCookieClickerContentScripts` and
`registerCookieClickerAutoDenyContentScripts` as two more injected
dependencies to `applySiteMode()`, matching its existing
dependency-injection style (`setFilteringMode`,
`registerContentScripts`, `registerSecurityContentScripts` were
already injected rather than imported directly), and added both calls
to `handleSiteModeSetAll()`'s own separate re-registration step.
`js/core/site-mode-manager.js`, `js/workflow/mode-routes.js`.

**Also checked, found not applicable here** (from the same
cross-check): a setting-repurposing bug and its consequent stale-test
bug (this project never repurposed `worryFreeSecurityTldProtectionsEnabled`'s
meaning — the new Privacy & Security row is an intentional second view
of the same setting, and `worry-free-extra-manager.js` already carries
explicit documentation warning against exactly that mistake); a DNR
ID-collision bug from picking IDs by eye (this project's own SCP
ranges were checked with `tools/check-dnr-id-ranges.mjs` before
shipping — still clean); and a missing-ruleset-allowlist-entry bug
(this project's SCP feature uses purely dynamic `modifyHeaders` rules,
never registered as static ruleset files in `manifest.json`, so
there's no static-ruleset allowlist entry that could be missing).

**Also ported as documentation only** (not a bug, not fixable): a
known Chrome/spec-level gap where an `allowAllRequests` DNR rule does
not reliably exempt Worker-initiated requests, observed for
RUM/analytics-beacon vendors (Akamai mPulse, Adobe Experience Cloud).
Documented next to `dnr.setAllowAllRules()` in `js/data/ext-compat.js`
so it isn't mistaken for a fixable regression in a future session.

### 12. Working-copy/checkout process gaps (not code bugs, v1.1.1)

Two environment issues in how this fork's three release artifacts
(extension/tools/docs, each its own zip) get reassembled into the
single working tree the check suite expects — not bugs in the shipped
product, but worth recording since they cost real time twice:
- `.depcheckrc.json` (a dotfile at the tools-artifact root) was
  silently skipped by a `cp *` glob during a manual merge, since bash
  doesn't expand `*` to dotfiles by default.
- `CHANGELOG.md` and `tools/package-release-state.json` are expected
  at specific fixed paths relative to `manifest.json` that don't match
  the three-zip split's own natural layout.

Both resolved by adopting `tools/package-release.mjs` and a persistent,
correctly-laid-out working copy (see `## 1.1.5`'s "PROJECT_FOLDER_NAME"
and adjacent entries) instead of ad hoc manual zip merging.

---

## Part 2 — Porting the Privacy & Security redesign to uBlock-Stripped-Dynamic

This section is a guide for applying the same redesign to the parent
project, which still has the original "Security & privacy" tab this
one was rebuilt from.

### What changed, at a glance

The original tab was a flat, two-column Security/Privacy grid
(`#security-columns`, `.security-row[data-column="security"|"privacy"]`)
gated behind a single "I am an advanced user" confirmation checkbox
(`#advancedUserGate`), with `#deleteHistoryGate` sitting above it as a
separate, ungated item.

The new tab ("Privacy & Security") is three risk-tiered groups, no
gate at all, every item using the same `.static-filter-row` markup the
Filter (block) lists tab already established — one shared visual
pattern across the whole dashboard instead of a bespoke layout per
tab.

### The new layout, exactly

```
Tab label: "Privacy & Security"  (was "Security & privacy")

── Group 1 ──────────────────────────────────────────────
"Safe privacy and security enhancements (enabled by default)"
  ☑ Clear history, cookies and cache at browser start
    (excluding passwords and site setting)
  ☑ Block sending (tracking) ping
  ☑ Block importing non-standard Web Bundles
  ☑ Block alert, confirm and prompt technical support scams

── Group 2 ──────────────────────────────────────────────
"Very low website breakage risk enhancements
 (enabled by default in Worry-free mode)"
  ☑ Block Suspicious 3P-links (from IP addresses only,
    non-standard ports, DDNS-servers)
  ☑ Block obfuscated scripts (only allow legitimate use
    of eval command)
  ☑ Enforce strict all EVAL block on high-risk websites,
    such as adult websites.
  ☑ Enforce low-risk Privacy inspector fingerprinting
    protections on high-risk websites.

── Group 3 ──────────────────────────────────────────────
"Low website breakage risk enhancements (enabled by default
 when 'safe regions' is enabled in Worry-free)"
  ☑ Enforce low-risk Privacy fingerprinting protections on
    websites not in the safe region TLD list.
  ☑ Block access to microphone, camera, screen capture and
    clipboard read for better privacy.
  ☑ Block access to Bluetooth, Serial, HID, USB, local
    network and downloads for better security.
  ☑ Block third-party scripts, frames and downloads from
    domains not in the safe region TLD list.
```

Every row's explanation lives in a `title=""` hover tooltip on the
`<label>`, not a permanently-visible `<legend>` line — same convention
the Filter (block) lists tab already uses.

### Exact hover-tooltip text, per item

Copied verbatim from the current `title=""` attributes — the visible
label above is what shows on the page; this is what shows on hover.

**Group 1**
- *Clear history, cookies and cache...* — "Uses
  chrome.browsingData.remove() to clear history, cookies, and cache on
  every genuine browser launch. Passwords and site permissions are
  never touched — Chrome itself ignores the passwords flag since
  Chrome 144, and there is no site-permissions data type in this API
  at all."
- *Block sending (tracking) ping* — "Stops hyperlink-auditing requests
  sent through the ping attribute on links. These requests can be
  fired silently for advertising, click tracking, and analytics. Use
  Privacy Inspector to block tracking beacons on individual websites."
- *Block importing non-standard Web Bundles* — "Web Bundles are a
  non-standard Chromium mechanism that can deliver multiple bundled
  responses through a single fetch. They may be abused to hide tracker
  payloads or bypass conventional request filtering."
- *Block alert, confirm and prompt technical support scams* —
  "Silences window.alert, window.confirm, and window.prompt — all
  three are abused by technical-support scam sites to trap users in
  repeated dialog boxes, to confuse and panic them, hoping they click
  on the false helpdesk prompt. Applies to all sites."

**Group 2**
- *Block Suspicious 3P-links...* — "Blocks third-party links matching
  any of three suspicious patterns: (1) is a bare IP number address,
  (2) opens non-standard ports (not 80, 8080, 443 or 8443), (3) links
  to a DDNS or free hosting website. Applies only during an active
  Worry-free session — unchecking this box opts out of that, it does
  not turn the protection on outside Worry-free."
- *Block obfuscated scripts...* — "Blocks eval() calls whose payload
  matches known obfuscation techniques, including Dean Edwards Packer,
  obfuscator.io patterns, encoded atob() payloads, and character-code
  encoding. Ordinary, legitimate eval() usage is allowed to continue.
  Applies only during an active Worry-free session — unchecking this
  box opts out of that, it does not turn the protection on outside
  Worry-free."
- *Enforce strict all EVAL block...* — "This may break site
  functionality on the affected pages, but it closes a common malware
  and exploit delivery technique used through cross-site scripting
  (XSS). Applies only during an active Worry-free session."
- *Enforce low-risk Privacy inspector fingerprinting protections...*
  — "Applies fingerprinting-detection mitigation (canvas, WebGL,
  GPU-fingerprint, plugins, battery status, timezone, audio, and
  WebRTC), directly to the same curated websites as the strict EVAL
  block above. Applies only during an active Worry-free session."

**Group 3**
- *Enforce low-risk Privacy fingerprinting protections on websites not
  in the safe region TLD list.* — "Applies low-risk
  fingerprinting-detection mitigation (canvas, WebGL, GPU-fingerprint,
  plugins, battery status, timezone, audio, and WebRTC), scoped to
  every domain outside your familiar-TLD list instead of a fixed site
  list. Applies only during an active Worry-free session — unchecking
  this box opts out of that; it does not turn the protection on
  outside Worry-free."
- *Block access to microphone, camera, screen capture and clipboard
  read for better privacy.* — "Injects a Permissions-Policy response
  header blocking camera, microphone, screen capture
  (display-capture), and clipboard read access — for the whole page
  and any embedded frames. Applies only during an active Worry-free
  session, only to sites outside your familiar-TLD list."
- *Block access to Bluetooth, Serial, HID, USB, local network and
  downloads for better security.* — "Injects a Permissions-Policy
  response header blocking Bluetooth, Serial, HID, and USB device
  access, and local-network-access (Chrome's own permission for
  reaching devices on your local network) — for the whole page and any
  embedded frames. Applies only during an active Worry-free session,
  only to sites outside your familiar-TLD list."
- *Block third-party scripts, frames and downloads from domains not in
  the safe region TLD list.* — "Blocks third-party code (scripts and
  frames) and downloads from domains outside your familiar, low-risk
  TLD list. Same setting as the Filter (block) lists tab's own
  Worry-free item of this name — edit the TLD list itself there."

### Where each piece lives

**`dashboard/dashboard.html`**
- Tab button label text: `Security &amp; privacy` → `Privacy &amp;
  Security`.
- The whole `<section data-pane="security">` block replaced: drop
  `#deleteHistoryGate`, `#advancedUserGate`, and `#security-columns`
  entirely; build the three groups above using
  `<h3 class="static-filters-heading">` / `<div
  class="static-filter-rows">` / `<div class="static-filter-row">`
  (the exact same markup the Filter lists tab's Built-in filter lists
  section already uses).
- `#securityAdvancedGroup` can be kept as a plain wrapping `<div>`
  around Groups 2-3 if you want a single element to hang future
  styling off — it does **not** need to carry any gating class; there
  is no gate anymore.

**`dashboard/security.js`** — rewritten down to two things:
`renderSecurityConfig()` (reflects stored config into every
`[data-setting]` checkbox in the section) and one `change` listener
that saves whichever checkbox changed. Everything gate-related
(`GATE_KEY`, `loadGateState()`/`applyGateState()`, the
`#advancedUserCheck` listener, `enableAllProtections()`'s
bulk-enable-on-unlock) is deleted outright — none of it has anything
left to gate.

**`dashboard/settings.css`** — remove `#security-columns`,
`.security-column-head*`, `.security-row*`, `#deleteHistoryGate`,
`#deleteHistoryGateLabel`, `#advancedUserGate`,
`#advancedUserGateLabel`, and the `.security-locked` opacity rule
(nothing is ever locked anymore). Nothing new needs adding — the three
groups reuse `.static-filters-heading`/`.static-filter-rows`/
`.static-filter-row`, already defined for the Filter lists tab.

**`js/data/config.js`** — `blockAlertDialogs` + `blockConfirmDialogs`
merge into one setting, `blockDialogSpam` (still two scriptlets under
the hood — `sec-alertbuster.js`, `sec-dialogbuster.js` — both keyed to
this one config value; verified safe because the consuming loop is a
`.filter()` over an array, not a Map keyed uniquely by setting name).
Defaults: Group 1's four settings `true`; Group 2/3's Worry-free-gated
settings **must** default `true` too, or the `!== false` opt-out gate
described in bug #8/#9 above silently breaks them — this is the single
easiest mistake to reintroduce when porting this change, so double
this specifically.

**`js/core/compiled-filters.js`** — `blockAlertDialogs`/
`blockConfirmDialogs`'s two `SECURITY_SCRIPTLETS` entries re-key to
`blockDialogSpam`. `blockAdultNoEval`/`blockAdultFingerprinting`
switch from `worryFreeOverride: true` to `worryFreeGatedOptOut: true`.
The `prepareSecurityScriptletDirectives()` filter function needs the
`worryFreeGatedOptOut` branch added (`isWorryFreeActive === true &&
securityConfig[s.key] !== false`, checked before the existing
`worryFreeOverride` OR-branch).

**`js/core/matrix-detect.js`** / **`js/core/ruleset-manager.js`** — if
porting the punycode removal too: `isSuspicious3pLink()` drops its
`PUNYCODE_LABEL_RE` check (down to IP-literal + non-standard-port);
the matching DNR rule slot (`SECURITY_RULES_BASE_ID+5`,
`regexFilter: '[./]xn--[^./]'`) is retired, not reassigned, per this
project's own ID-retirement convention.

**If porting the SCP feature too** (camera/mic/screen-capture/
clipboard, Bluetooth/Serial/HID/USB/local-network) — this is
substantially more work than the layout/relabeling above:
- New DNR budget constants in `js/core/dnr-budgets.js` for two
  `modifyHeaders` block rules and a third familiar-TLD-allow purpose
  (needs its own `main_frame`-inclusive exemption band — see bug #5).
- `ruleset-manager.js`'s generic `modifyHeaders` slot builder needs
  `responseHeaders` support added (it only wired `requestHeaders`
  before, since GPC — its only prior user — never needed a response
  header).
- `worry-free-familiar-tld-manager.js`'s `buildTldAllowRules()` needs
  the `domainType` parameter from bug #5, and a third
  `applyFamiliarTldRules()` call for the SCP exemption band.
- The fingerprinting-scoped-to-non-familiar-TLD item reuses the
  existing `sec-adult-fingerprint` scriptlet with a second, uniquely-ID'd
  registration — see bug #6's `scriptFile` field.

/*******************************************************************************

    uBlock-Stripped-Dynamic — Power-tools "More"/"Less" toggle

    Wires #powerToolsMoreLessToggle to a persisted chrome.storage.local
    setting, and shows/hides #powerToolsSection accordingly — same uBO
    popup convention as the reference screenshot this replaced an earlier,
    checkbox-based design with (a settings-page-style checkbox row read as
    "a setting to go find," not "part of this same menu" — the More/Less
    toggle reads as part of the menu itself, matching the pattern people
    already know from uBO's own popup).

    Reuses css/fa-icons.css's `angle-up` icon + `.fa-icon-vflipped` class —
    both already existed in this fork, declared for exactly this "picker
    more/less" purpose per fa-icons.js's own comment, never actually wired
    up anywhere until now (C21: reuse a proven pattern, don't invent a
    second one next to it).

    Purely a UI-visibility concern — this file does not touch any of the
    individual power-tool features themselves (those keep their own
    existing click handlers in popup.js / cookie-clicker-autodeny-ui.js,
    unchanged).

    #powerToolsSection and the toggle itself both carry the `needHTTP`
    class (see popup.css) — on a protected tab (chrome://, the extension
    gallery, etc.) the whole "power tools" concept, including the toggle
    that would reveal it, stays hidden regardless of this setting, since
    none of the tools it reveals can act on a page like that anyway.

*******************************************************************************/

import { localRead, localWrite } from '../js/data/ext.js';
import { qs$ } from '../js/ui/dom.js';

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

const POWER_TOOLS_STORAGE_KEY = 'popup.powerToolsEnabled';
const LABEL_COLLAPSED = 'More (show power tools)';
const LABEL_EXPANDED  = 'Less (hide power tools)';

/******************************************************************************/

function applyState(expanded) {
    const section = qs$('#powerToolsSection');
    const icon    = qs$('#powerToolsMoreLessIcon');
    const label   = qs$('#powerToolsMoreLessLabel');
    if ( section !== null ) { section.hidden = expanded !== true; }
    // .fa-icon-vflipped = chevron pointing down ("More" — there's more
    // below to reveal). Removing it = chevron pointing up ("Less" —
    // collapse what's currently shown). Same up/down convention the
    // reference screenshot uses.
    if ( icon !== null ) { icon.classList.toggle('fa-icon-vflipped', expanded !== true); }
    if ( label !== null ) { label.textContent = expanded ? LABEL_EXPANDED : LABEL_COLLAPSED; }
}

async function initPowerToolsToggle() {
    const toggle = qs$('#powerToolsMoreLessToggle');
    if ( toggle === null ) { return; }

    // INIT guard — read the persisted setting once, on popup open.
    // Default to collapsed ("More") for anyone who's never touched this
    // setting, i.e. every existing user right after this feature ships,
    // per the person's own explicit "initially set to More" instruction.
    let expanded = false;
    try {
        const stored = await localRead(POWER_TOOLS_STORAGE_KEY);
        expanded = stored === true;
    } catch {
        // Storage read failed (rare) — fall back to the same collapsed
        // default a first-ever run would use.
    }

    applyState(expanded);

    async function toggleState() {
        expanded = !expanded;
        applyState(expanded);
        try {
            await localWrite(POWER_TOOLS_STORAGE_KEY, expanded);
        } catch {
            // RELEASE-adjacent guard: a failed write leaves the visible
            // state (already applied above) out of sync with storage for
            // this one popup session — acceptable degraded behavior (the
            // toggle still visually reflects what the person just
            // clicked) rather than rolling the UI back and confusing them
            // about whether their click registered at all.
        }
    }

    toggle.addEventListener('click', toggleState);
    toggle.addEventListener('keydown', ev => {
        if ( ev.key !== 'Enter' && ev.key !== ' ' ) { return; }
        ev.preventDefault();
        toggleState();
    });
}

initPowerToolsToggle();

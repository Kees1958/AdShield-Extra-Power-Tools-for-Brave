/*
 * matrix-detect.js — Pure "suspicious 3P link" detection predicates
 *
 * Ported from 3P-Matrix-lite's design (punycode/IP/port checks did not
 * exist there as reusable functions — the punycode check already lived in
 * uBol-stripped's own js/util/punycode.js + ruleset-manager.js DNR slot;
 * this module adds the two 3P-Matrix-lite-inspired checks that DNR's RE2
 * regex engine cannot express safely on its own: IP-literal hosts (safe as
 * a positive DNR regexFilter, included here too for a single shared
 * source of truth) and non-standard explicit ports (NOT safe as a single
 * DNR regexFilter, since RE2 has no negative lookahead — see
 * MATRIX_DETECT_CONFIG.ALLOWED_EXPLICIT_PORTS below for how the DNR side
 * composes an allow-then-block pair instead of negating in one regex).
 *
 * Public interface:
 *   isIpLiteralHost(hostname)        — true if hostname is a bare IPv4 or
 *                                       bracketed-IPv6 literal, not a domain name
 *   isNonStandardPortUrl(url)        — true if the URL has an EXPLICIT port
 *                                       that is not in the allowed list below
 *   isSuspicious3pLink(url)          — true if IP-literal OR
 *                                       non-standard-port (the combined
 *                                       "Block suspicious 3P-links" check
 *                                       — punycode detection REMOVED per
 *                                       explicit request)
 *   MATRIX_DETECT_CONFIG              — single source of truth for every
 *                                       magic number/list this module uses
 *
 * No state, no caching, no listeners — every function is a pure
 * hostname/URL -> boolean mapping with no side effects, so there is
 * nothing here that needs an init/clear/release guard (see
 * Injection-architecture-evaluation.md's "no cache, so no cache-eviction
 * logic to get wrong" reasoning — the same principle applies at function
 * scope here, not just at the injection-architecture scale it was
 * originally written about).
 */

/******************************************************************************/
// Config — single source of truth for every constant this module uses.
// Nothing below is duplicated or re-declared elsewhere; other modules must
// import these constants rather than hard-coding their own copies.
/******************************************************************************/

export const MATRIX_DETECT_CONFIG = Object.freeze({
    // Explicit ports considered "standard" for legitimate third-party
    // origins — CDNs, reverse proxies, and dev-adjacent hosting commonly
    // use these even in production. Any OTHER explicit port on a
    // third-party URL is treated as suspicious. Referenced by both this
    // module (isNonStandardPortUrl) and the DNR rule builder in Stage 2
    // (which must allow-list these same ports at higher DNR priority
    // before applying its own general "any explicit port" block regex —
    // see that module's own header for the allow/block composition).
    ALLOWED_EXPLICIT_PORTS: Object.freeze([ 80, 443, 8080, 8443 ]),

    // Matches an IPv4 dotted-quad literal, anchored so "1.2.3.4.evil.com"
    // (a real domain name that merely starts with digits) does NOT match —
    // the whole hostname must be nothing but the four octets.
    IPV4_LITERAL_RE: /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,

    // Matches a bracketed IPv6 literal as it appears in a URL authority,
    // e.g. "[2001:db8::1]". Deliberately permissive about the inner
    // content (full IPv6 validation is not this module's job) — the
    // bracket shape alone is what distinguishes "this is a literal
    // address, not a hostname" for our purposes.
    IPV6_LITERAL_RE: /^\[[0-9a-fA-F:]+\]$/,
});

/******************************************************************************/

// Each octet of an IPv4 literal must be 0-255 for the value to actually be
// a routable address rather than four arbitrary digit groups that merely
// look like one syntactically.
function isValidIpv4Octets(hostname) {
    const parts = hostname.split('.');
    for ( let i = 0; i < parts.length; i++ ) {
        const n = Number(parts[i]);
        if ( n < 0 || n > 255 ) { return false; }
    }
    return true;
}

/******************************************************************************/

export function isIpLiteralHost(hostname) {
    if ( typeof hostname !== 'string' || hostname.length === 0 ) { return false; }
    if ( MATRIX_DETECT_CONFIG.IPV6_LITERAL_RE.test(hostname) ) { return true; }
    if ( MATRIX_DETECT_CONFIG.IPV4_LITERAL_RE.test(hostname) === false ) { return false; }
    return isValidIpv4Octets(hostname);
}

/******************************************************************************/

export function isNonStandardPortUrl(url) {
    let parsed;
    try {
        parsed = new URL(url);
    } catch {
        return false; // malformed URL — treat as no match, not a crash
    }
    if ( parsed.port === '' ) { return false; } // no explicit port — nothing to flag
    const port = Number(parsed.port);
    return MATRIX_DETECT_CONFIG.ALLOWED_EXPLICIT_PORTS.includes(port) === false;
}

/******************************************************************************/

// Combined "suspicious 3P link" check — IP-literal OR non-standard port.
// BRAVE VARIANT — punycode detection REMOVED entirely per explicit
// request (was a third condition here; the matching DNR rule slot
// SECURITY_RULES_BASE_ID+5 in ruleset-manager.js is retired too).
export function isSuspicious3pLink(url) {
    let parsed;
    try {
        parsed = new URL(url);
    } catch {
        return false;
    }
    if ( isIpLiteralHost(parsed.hostname) ) { return true; }
    if ( isNonStandardPortUrl(url) ) { return true; }
    return false;
}

/******************************************************************************/

/*
 * history-cleaner.js — "Delete browser history, cookies and cache
 * (except passwords and site permissions) at start" Security & Privacy
 * toggle.
 *
 * Approach inspired by (not a copy of) github.com/dessant/clear-browsing-
 * data's use of the chrome.browsingData API — that extension supports many
 * data types (cookies, cache, downloads, form data, etc.); this feature
 * deliberately covers ONLY history + cookies + cache, matching the
 * checkbox's own literal label — not the full set that extension offers.
 * Extending to more data types later just means adding more `true` keys
 * to the dataToRemove object in deleteBrowsingData() below, following the
 * exact same guarded/logged shape.
 *
 * WARNING FOR IMPLEMENTATION IMPACT: clearing cookies signs the person out
 * of every website on every browser launch this is enabled — a real,
 * user-visible tradeoff, not a "no breakage risk" toggle like the
 * history-only version this used to be. That's the whole point of the
 * setting, not a bug, but it's why this stays its own explicit opt-in
 * rather than being silently bundled into something else.
 *
 * Passwords and site permissions are both guaranteed untouched — for two
 * different reasons, verified directly against Chrome's current API
 * reference (not assumed):
 *   - `passwords` is a real DataTypeSet key, but chrome.browsingData
 *     itself has removed all effect from it since Chrome 144 — the API
 *     accepts the flag but silently ignores it now, so no extension can
 *     delete saved passwords through this API at all anymore, regardless
 *     of what's passed.
 *   - Site permissions (camera/microphone/location/notification grants,
 *     etc.) have NO corresponding DataTypeSet key in chrome.browsingData
 *     at all — there is no data type name that could remove them even if
 *     this file wanted to.
 * Either way, only ever setting the three keys below is what actually
 * matters — never setting a key is always sufficient to guarantee this
 * feature can't touch it, so no special-cased exclusion logic is needed
 * anywhere in this file regardless of which of the two reasons applies.
 *
 * Public interface:
 *   deleteHistoryOnBrowserStartup() — called once from background.js's
 *                                      browser.runtime.onStartup listener;
 *                                      no-ops unless securityConfig.
 *                                      deleteHistoryOnStart is true
 */

import { browser } from '../data/ext.js';
import { securityConfig } from '../data/config.js';

/******************************************************************************/
// Config — single source of truth for exactly what gets cleared here,
// per this project's config-in-one-place convention.
/******************************************************************************/

// chrome.browsingData.remove()'s `since` field: epoch-ms cutoff, requests
// older than this are removed. 0 = the beginning of time — matches this
// toggle's "clear it all, every launch" intent rather than a rolling
// window.
const REMOVE_SINCE_EPOCH_MS = 0;

// Exactly these three data types, deliberately — see file header.
// `cacheStorage` (the Cache Storage API, distinct from the older `cache`
// key) is included alongside `cache` since a plain "cache" checkbox
// reads as covering both to anyone not already familiar with the API's
// own internal split. `passwords` isn't set (and Chrome ignores it even
// if it were, since Chrome 144); site permissions have no corresponding
// key in this API at all. NOT exported: nothing outside
// deleteBrowsingData() below should need to know this shape, keeping
// "what gets deleted" defined in exactly one place.
const STARTUP_DATA_TO_REMOVE = Object.freeze({
    history: true,
    cookies: true,
    cache: true,
    cacheStorage: true,
});

/******************************************************************************/

async function deleteBrowsingData() {
    // Guard: browser.browsingData is only present when the "browsingData"
    // permission (manifest.json) is actually granted — absent on a build
    // where it was stripped, or (defensively) if a future manifest change
    // ever drops it without updating this file. Fails closed (does
    // nothing) rather than throwing and interrupting SW startup.
    if ( browser.browsingData?.remove === undefined ) {
        console.error('[uBlock-Dynamic] history-cleaner: browsingData API unavailable — permission missing?');
        return;
    }
    try {
        await browser.browsingData.remove(
            { since: REMOVE_SINCE_EPOCH_MS },
            STARTUP_DATA_TO_REMOVE,
        );
    } catch (reason) {
        console.error('[uBlock-Dynamic] history-cleaner/deleteBrowsingData:', reason);
    }
}

/******************************************************************************/

// Called once from background.js's browser.runtime.onStartup listener —
// which fires only on a genuine browser launch, never on the routine
// service-worker sleep/wake cycles MV3 does constantly within a single
// browser session (see temp-disable-manager.js's own onStartup comment
// for the identical reasoning — "at start" means browser start, not every
// SW wakeup, or this would silently wipe this data on an unpredictable,
// far-more-frequent schedule than the checkbox's label promises).
export async function deleteHistoryOnBrowserStartup() {
    if ( securityConfig.deleteHistoryOnStart !== true ) { return; }
    await deleteBrowsingData();
}

/******************************************************************************/

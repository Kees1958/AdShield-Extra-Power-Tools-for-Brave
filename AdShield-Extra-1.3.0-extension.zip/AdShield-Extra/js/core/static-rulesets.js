/*******************************************************************************

    uBol-stripped — Static ruleset manager
    Reads and toggles the built-in filter list rulesets via the
    declarativeNetRequest.updateEnabledRulesets() API.
    Chrome persists enabled/disabled state across service-worker and browser
    restarts automatically — but NOT across an extension version update,
    where it resets to manifest.json's declared defaults instead. This
    module persists the user's own choices separately to survive that case
    too (see OVERRIDES_STORAGE_KEY below).

*******************************************************************************/
/*
 * static-rulesets.js — Static ruleset enable/disable
 *
 * Public interface:
 *   getEnabledRulesets()              — returns Set of currently enabled ruleset IDs
 *   setRulesetEnabled(id, enabled)    — enables or disables a static ruleset,
 *                                       cascading to any companion ruleset(s)
 *                                       registered in RULESET_COMPANIONS
 *                                       (js/data/ruleset-companions.js);
 *                                       also persists the choice (see below)
 *   restoreEnabledRulesetsFromStorage() — reapplies persisted user choices;
 *                                       call once per SW startup (background.js)
 *
 * The list of valid IDs is STATIC_RULESET_IDS (must match manifest.json rule_resources).
 */


import { dnr } from '../data/ext-compat.js';
import { localRead, localWrite } from '../data/ext.js';
import { RULESET_COMPANIONS } from '../data/ruleset-companions.js';

// ── PERSISTED OVERRIDES ──────────────────────────────────────────────────
// Chrome's declarativeNetRequest.updateEnabledRulesets() state does NOT
// reliably survive an extension *version update* — on update, Chrome
// re-applies the enabled/disabled defaults declared in manifest.json's
// rule_resources[], discarding any runtime toggle the user made (e.g.
// turning on the opt-in "AdGuard Anti-Adblock" list). The comment that used
// to sit on setRulesetEnabled() ("Chrome persists the state — no storage
// write needed") was true only across service-worker/browser restarts
// while the same version stays installed — not across updates. This module
// now tracks the user's own choices independently and reapplies them once
// per SW startup (see restoreEnabledRulesetsFromStorage(), called from
// startSession() in background.js), so a version bump can never silently
// revert a deliberate choice again.
const OVERRIDES_STORAGE_KEY = 'enabledRulesetOverrides';

/******************************************************************************/

// All static ruleset IDs declared in manifest.json rule_resources.
// Must stay in sync with tools/build-rulesets.mjs FILTER_LISTS[].id.
//
// BRAVE VARIANT (v1.0.0) — trimmed from the full uBlock-Stripped-Dynamic
// ruleset set. Brave's own built-in Shields already does general network-
// level ad/tracker blocking, so this variant deliberately drops the large,
// general-purpose block lists and keeps only Kees1958's small curated
// core list plus the "Worry-free" session tooling (Matrix panel, Privacy
// Inspector, Security & Privacy scriptlets, etc.) that Shields has no
// equivalent for. Removed entirely (not just disabled) vs. the full
// variant, along with every hidden companion that only existed to support
// them:
//   - 'ruleset_kees1958_tracking'   ($removeparam list)
//   - 'ruleset_adguard_base'        (large general block+cosmetic list)
//   - 'ruleset_adguard_base_adult'  (build-time-derived from the line above —
//                                    cannot be regenerated without it)
//   - all AdGuard/EasyList "language filters" and their
//     'ruleset_agbase_overflow_*' / 'ruleset_adguard_*_removeparam' companions
export const STATIC_RULESET_IDS = [
    // Core — enabled by default
    'ruleset_disconnect_other',
    // Optional annoyance filters — enabled by default (v8.3.2); user-toggled in dashboard Worry-free settings tab.
    // NOTE: ruleset file is a build-time output of tools/build-rulesets.mjs fetching
    //       AnnoyancesFilter/Popups/sections/antiadblock.txt — run the build before enabling.
    'ruleset_adguard_antiadblock',
    // Anti-Admiral (v8.3.2) — dedicated block against getadmiral.com's ad-recovery/
    // ad-block-circumvention network ("Admiral", also branded "Ad-Shield"). Distinct
    // from ruleset_adguard_antiadblock above: that one is AdGuard's own general
    // anti-adblock-circumvention list (a different upstream source, different
    // vendor coverage); this one is specifically Admiral/GetAdmiral infrastructure,
    // combined + deduplicated at build time from three independent open-source
    // sources (HaGeZi's ad-shield.txt, EasyList's easyprivacy_trackingservers_
    // admiral.txt, LanikSJ's getadmiral-domains.txt) — see
    // tools/build-rulesets.mjs's buildAntiAdmiralRuleset() for the exact
    // fetch/normalize/dedup logic and each source's own format quirks.
    // Enabled by default: unlike general anti-adblock bypass (which can carry some
    // site-breakage risk from broader circumvention scriptlets), this is pure
    // domain-blocking against one specific, well-documented ad-recovery vendor.
    'ruleset_antiadmiral',
];

/******************************************************************************/

// Returns a Set of currently enabled ruleset IDs.
export async function getEnabledRulesets() {
    try {
        const enabled = await dnr.getEnabledRulesets();
        return new Set(Array.isArray(enabled) ? enabled : []);
    } catch {
        return new Set();
    }
}

/******************************************************************************/

// Enable or disable a single static ruleset by ID. Also enables/disables
// any companion ruleset(s) registered for it in RULESET_COMPANIONS (e.g.
// toggling the visible "AdGuard Dutch filter" also toggles its hidden
// AG-Base-overflow companion) — see js/data/ruleset-companions.js.
// Persists the user's choice (see OVERRIDES_STORAGE_KEY above) so it can be
// reapplied on the next startup — Chrome's own DNR state does not survive
// an extension version update.
export async function setRulesetEnabled(id, enabled) {
    if ( !STATIC_RULESET_IDS.includes(id) ) { return; }

    // Collect id + companions, filtering out any companion id that isn't
    // actually a known static ruleset (defensive — e.g. if a build ran
    // without countryOverflow and the *-overflow-* files don't exist,
    // updateEnabledRulesets() would otherwise throw for the whole batch).
    const companions = (RULESET_COMPANIONS[id] ?? []).filter(cid => STATIC_RULESET_IDS.includes(cid));
    const ids = [ id, ...companions ];

    // Single atomic call for id + all its companions together (C14 —
    // atomic state transitions: a partial enable/disable across id and its
    // companions would leave AG Base's overflow content out of sync with
    // the visible filter it belongs to).
    try {
        await dnr.updateEnabledRulesets({
            enableRulesetIds:  enabled ? ids : [],
            disableRulesetIds: enabled ? [] : ids,
        });
    } catch (err) {
        console.error(`[uBlock-Dynamic] setRulesetEnabled(${id}, ${enabled}):`, err);
        return;
    }

    // Only persist on a successful DNR update — an override that was never
    // actually applied shouldn't be remembered as the user's choice.
    // Companions are intentionally NOT persisted individually here: they're
    // re-derived from RULESET_COMPANIONS every time `id` itself is restored
    // (see restoreEnabledRulesetsFromStorage() below), so the mapping stays
    // the single source of truth even if it changes in a future version.
    try {
        const overrides = await localRead(OVERRIDES_STORAGE_KEY) ?? {};
        overrides[id] = enabled;
        await localWrite(OVERRIDES_STORAGE_KEY, overrides);
    } catch (err) {
        console.error(`[uBlock-Dynamic] setRulesetEnabled(${id}, ${enabled}): failed to persist override:`, err);
    }
}

/******************************************************************************/

// Reapply every persisted user override, restoring deliberate choices that
// Chrome may have just reset to manifest defaults on this version's update.
// Called once from startSession() in background.js — the same place that
// already knows "this is a fresh install or version bump", which is
// precisely when Chrome's own DNR enabled-state can have been reset.
export async function restoreEnabledRulesetsFromStorage() {
    let overrides;
    try {
        overrides = await localRead(OVERRIDES_STORAGE_KEY) ?? {};
    } catch (err) {
        console.error('[uBlock-Dynamic] restoreEnabledRulesetsFromStorage: failed to read overrides:', err);
        return;
    }
    const ids = Object.keys(overrides).filter(id => STATIC_RULESET_IDS.includes(id));
    if ( ids.length === 0 ) { return; }
    // Sequential, not Promise.all: setRulesetEnabled() issues its own
    // updateEnabledRulesets() call per id (plus companions) — running them
    // concurrently would let overlapping calls race on Chrome's internal
    // ruleset state. This only runs once per SW startup and the override
    // set is typically small, so sequential is not a meaningful cost.
    for ( const id of ids ) {
        await setRulesetEnabled(id, overrides[id]);
    }
}

/******************************************************************************/

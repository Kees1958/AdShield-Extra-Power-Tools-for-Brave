/*
 * ruleset-routes.js — Ruleset toggle / DNR data message-route adapters
 *
 * Same three-layer split as matrix-routes.js / security-routes.js (see
 * matrix-routes.js's own header for the full rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER
 *   Layer 3 — ruleset-manager.js, static-rulesets.js, scripting-manager.js,
 *             static-block-check.js, and the raw dnr API (data/ext-compat.js)
 *             — the actual logic
 *
 * Two of these six (getAllDynamicRules, getAllSessionRules) are pure
 * pass-throughs straight to the browser's own declarativeNetRequest API —
 * no core/ module involved at all, included here anyway since they're
 * DNR-data reads in the same family as the other four, not because they
 * share an implementation with them.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleGetAllDynamicRules, handleGetAllSessionRules,
 *   handleUpdateUserDnrRules, handleGetEffectiveUserRules,
 *   handleGetEnabledRulesets, handleSetRulesetEnabled,
 *   handleGetWorryFreeFamiliarTlds, handleSetWorryFreeFamiliarTlds,
 *   handleRestoreWorryFreeFamiliarTlds
 */

import { dnr } from '../data/ext-compat.js';

import { updateUserRules, getEffectiveUserRules } from '../core/ruleset-manager.js';
import { getEnabledRulesets, setRulesetEnabled } from '../core/static-rulesets.js';
import { resetStaticBlockCache } from '../core/static-block-check.js';
import {
    registerScriptletContentScripts,
    registerCosmeticContentScripts,
    registerSecurityContentScripts,
} from '../core/scripting-manager.js';
import {
    getFamiliarTlds,
    setFamiliarTlds,
    restoreFamiliarTldsToDefault,
} from '../core/worry-free-familiar-tld-manager.js';

/******************************************************************************/

export async function handleGetAllDynamicRules() {
    return dnr.getDynamicRules();
}

export async function handleGetAllSessionRules() {
    return dnr.getSessionRules();
}

export async function handleUpdateUserDnrRules() {
    return updateUserRules();
}

export async function handleGetEffectiveUserRules() {
    return getEffectiveUserRules();
}

export async function handleGetEnabledRulesets() {
    return getEnabledRulesets().then(s => [...s]);
}

export async function handleSetRulesetEnabled(request) {
    await setRulesetEnabled(request.id, request.enabled);
    // Re-register scriptlet + cosmetic content scripts and user scripts so
    // the new enabled set takes effect immediately.
    registerScriptletContentScripts();
    registerCosmeticContentScripts();
    // DDG Tracker Radar's static-block check (js/core/static-block-check.js)
    // caches which domains are whole-domain-blocked by the currently
    // enabled rulesets — that selection just changed, so drop the cache.
    resetStaticBlockCache();

    return getEnabledRulesets().then(s => [...s]);
}

/******************************************************************************/
// Familiar-TLD editor (BRAVE VARIANT — Worry-free settings' "Extra
// security protection" TLD textarea) — see worry-free-familiar-tld-
// manager.js's own header for what each of these actually does.
/******************************************************************************/

export async function handleGetWorryFreeFamiliarTlds() {
    return getFamiliarTlds();
}

export async function handleSetWorryFreeFamiliarTlds(request) {
    const result = await setFamiliarTlds(request.text);
    // blockScpFingerprint's own exclude-matches are computed from this
    // same TLD list (see compiled-filters.js's SECURITY_SCRIPTLETS
    // entry) — re-register so it reflects the change immediately, not
    // just on the next unrelated security-config change.
    await registerSecurityContentScripts();
    return result;
}

export async function handleRestoreWorryFreeFamiliarTlds() {
    const result = await restoreFamiliarTldsToDefault();
    await registerSecurityContentScripts();
    return result;
}

/******************************************************************************/

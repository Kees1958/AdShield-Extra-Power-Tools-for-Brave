/*
 * sec-nowebrtc.js — Security scriptlet: blockWebRTC toggle
 *
 * Blocks RTCPeerConnection ONLY when STUN/TURN servers are configured — the
 * actual IP-leak vector. Connections with no iceServers (used by Chrome
 * internally for audio output device routing, e.g. headphone switching) are
 * passed through so headphone audio continues to work.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 *
 * Uses const/let, not var: this whole file's body sits inside the
 * (function(){...})() IIFE below, so each re-injection gets a fresh
 * function scope — no top-level redeclaration hazard to guard against.
 */
'use strict';
(function(){'use strict';
            const rtcName = window.RTCPeerConnection ? 'RTCPeerConnection'
                : window.webkitRTCPeerConnection ? 'webkitRTCPeerConnection' : '';
            if ( rtcName === '' ) { return; }
            const OriginalRTC = window[rtcName];
            const neuteredSet = new WeakSet();
            function hasStunTurn(instance, config) {
                if ( neuteredSet.has(instance) ) { return true; }
                if ( config instanceof Object === false ) { return false; }
                if ( Array.isArray(config.iceServers) === false ) { return false; }
                if ( config.iceServers.length === 0 ) { return false; }
                neuteredSet.add(instance);
                return true;
            }
            window[rtcName] = new Proxy(OriginalRTC, {
                construct: function(target, args) {
                    const inst = Reflect.construct(target, args);
                    if ( hasStunTurn(inst, args[0]) ) {
                        console.info('[uBol] RTCPeerConnection with STUN/TURN blocked:', args[0]);
                        return Reflect.construct(target, []);
                    }
                    return inst;
                }
            });
            OriginalRTC.prototype.createDataChannel = new Proxy(
                OriginalRTC.prototype.createDataChannel, {
                    apply: function(target, thisArg, args) {
                        if ( neuteredSet.has(thisArg) ) {
                            return { close: function(){}, send: function(){} };
                        }
                        return Reflect.apply(target, thisArg, args);
                    }
                }
            );
        })();

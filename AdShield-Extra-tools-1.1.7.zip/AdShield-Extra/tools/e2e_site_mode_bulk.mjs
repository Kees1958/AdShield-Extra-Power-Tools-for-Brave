// Behavioral proof for v9.4.9 porting item 7 (bulk site-mode save does N
// round-trips instead of 1). Exercises the real exported functions from
// mode-manager.js — not just "does it parse":
//   - setFilteringModesBulk() must produce an IDENTICAL end state to
//     calling setFilteringMode() sequentially for the same inputs
//     (the doc's own recommended equivalence check)
//   - setFilteringModesBulk() must do exactly ONE storage write cycle and
//     ONE DNR rebuild for N hostnames, not N of each
//
// Each scenario runs in its OWN Node process (tools/_e2e_helpers/
// site_mode_scenario.mjs) — required because js/data/ext.js captures the
// browser/chrome global once at first import (plain relative import, no
// cache-busting query), so two scenarios sharing one process would
// silently both hit whichever mock was installed first. Found this the
// hard way: an earlier single-process version of this test reported
// zero storage writes for the bulk scenario — not a real bug, a test
// artifact — before being restructured this way.
import { execFileSync } from 'child_process';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

console.log('=== e2e: mode-manager.js setFilteringModesBulk() vs sequential setFilteringMode() ===\n');

let failures = 0;
function check(name, cond) {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}`); }
}

function runScenario(name) {
    const out = execFileSync(
        process.execPath,
        [ 'tools/_e2e_helpers/site_mode_scenario.mjs', name ],
        { cwd: ROOT, encoding: 'utf8', timeout: 15000 }
    );
    return JSON.parse(out);
}

const sequential = runScenario('sequential');
const bulk = runScenario('bulk');

console.log(`    sequential: ${JSON.stringify(sequential.counts)}`);
console.log(`    bulk:       ${JSON.stringify(bulk.counts)}`);

const N = 4; // testHostnames.length in the scenario helper

check(
    `sequential calls did ${N} local storage writes for ${N} hostnames`,
    sequential.counts.localSetCalls === N
);
check(
    `sequential calls did ${N} DNR rebuilds for ${N} hostnames`,
    sequential.counts.dnrUpdateCalls === N
);
check(
    `bulk call did exactly 1 local storage write for the same ${N} hostnames`,
    bulk.counts.localSetCalls === 1
);
check(
    `sequential calls did ${N + 1} session storage writes (${N} real + 1 one-time cold-start cache warm-up)`,
    sequential.counts.sessionSetCalls === N + 1
);
check(
    'bulk call did exactly 2 session storage writes (1 real + the same one-time cold-start cache warm-up, not N+1)',
    bulk.counts.sessionSetCalls === 2
);
check(
    'bulk call did exactly 1 DNR rebuild (not N)',
    bulk.counts.dnrUpdateCalls === 1
);

// The actual equivalence check the porting guide recommends: bulk and
// sequential must produce an IDENTICAL end state for the same inputs.
check(
    'bulk-applying N changes produces an IDENTICAL stored end state to sequential single-item calls',
    JSON.stringify(sequential.finalState) === JSON.stringify(bulk.finalState)
);
console.log(`    sequential final state: ${JSON.stringify(sequential.finalState)}`);
console.log(`    bulk final state:       ${JSON.stringify(bulk.finalState)}`);

console.log(`\n${failures === 0 ? 'PASS' : 'FAIL'}: e2e site-mode bulk check (${failures} failure(s))`);
process.exit(failures === 0 ? 0 : 1);

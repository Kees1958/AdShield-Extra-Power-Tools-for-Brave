// Behavioral proof for v9.4.9 porting item 1 (remove the blanket
// content-script wipe): registers a content script under an id the
// scripting-manager orchestrator does not own, runs the real, exported
// registerContentScripts(), and asserts that unrelated id still exists
// afterward. This is the actual proof the blanket-wipe removal is safe
// — "it didn't throw" is not sufficient, per the porting guide's own
// verification-approach section.
import assert from 'assert';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

// ── Mock browser.scripting — a real in-memory registry, not a stub that
//    just resolves. get/register/update/unregister all operate on the
//    same Map, so this actually behaves like the real API for the
//    purposes of this test (an id "exists" iff it's in the Map).
const registered = new Map();
const scriptingMock = {
    async getRegisteredContentScripts(filter) {
        const all = [ ...registered.values() ];
        if ( filter && Array.isArray(filter.ids) ) {
            return all.filter(s => filter.ids.includes(s.id));
        }
        return all;
    },
    async registerContentScripts(directives) {
        for ( const d of directives ) {
            if ( registered.has(d.id) ) { throw new Error(`Duplicate script ID '${d.id}'`); }
            registered.set(d.id, d);
        }
    },
    async updateContentScripts(directives) {
        for ( const d of directives ) {
            if ( !registered.has(d.id) ) { throw new Error(`Script with ID '${d.id}' does not exist or is not fully registered`); }
            registered.set(d.id, d);
        }
    },
    async unregisterContentScripts(filter) {
        if ( filter === undefined ) { registered.clear(); return; }
        for ( const id of filter.ids ) { registered.delete(id); }
    },
};

const store = { local: {}, session: {} };
function makeStorageArea(area) {
    return {
        get: (key) => {
            if ( key === undefined || key === null ) { return Promise.resolve({ ...store[area] }); }
            if ( typeof key === 'string' ) { return Promise.resolve({ [key]: store[area][key] }); }
            if ( Array.isArray(key) ) {
                const out = {};
                for ( const k of key ) { out[k] = store[area][k]; }
                return Promise.resolve(out);
            }
            // object form: key is a set of defaults
            const out = {};
            for ( const k of Object.keys(key) ) { out[k] = store[area][k] ?? key[k]; }
            return Promise.resolve(out);
        },
        set: (obj) => { Object.assign(store[area], obj); return Promise.resolve(); },
        remove: (keys) => { for ( const k of [].concat(keys) ) { delete store[area][k]; } return Promise.resolve(); },
    };
}

const realFetch = global.fetch;
global.fetch = async (url) => {
    const prefix = 'chrome-extension://test/';
    if ( typeof url === 'string' && url.startsWith(prefix) ) {
        const fs = await import('fs/promises');
        try {
            const text = await fs.readFile(path.join(ROOT, url.slice(prefix.length)), 'utf8');
            return { ok: true, status: 200, json: async () => JSON.parse(text), text: async () => text };
        } catch {
            return { ok: false, status: 404, json: async () => { throw new Error('not found'); } };
        }
    }
    return realFetch(url);
};

global.browser = {
    scripting: scriptingMock,
    storage: {
        local: makeStorageArea('local'),
        session: makeStorageArea('session'),
        onChanged: { addListener(){} },
    },
    runtime: { getURL: p => `chrome-extension://test/${p}`, id: 'test' },
    action: {
        setIcon: () => Promise.resolve(),
        setBadgeText: () => Promise.resolve(),
        setBadgeBackgroundColor: () => Promise.resolve(),
        setTitle: () => Promise.resolve(),
    },
    alarms: {
        create: () => {},
        clear: () => Promise.resolve(true),
        onAlarm: { addListener(){} },
    },
    permissions: {
        getAll: () => Promise.resolve({ origins: [ '<all_urls>' ], permissions: [] }),
        onAdded: { addListener(){} },
        onRemoved: { addListener(){} },
    },
    declarativeNetRequest: {
        getDynamicRules: () => Promise.resolve([]),
        updateDynamicRules: () => Promise.resolve(),
        getSessionRules: () => Promise.resolve([]),
        updateSessionRules: () => Promise.resolve(),
        getEnabledRulesets: () => Promise.resolve([]),
        updateEnabledRulesets: () => Promise.resolve(),
    },
    tabs: {
        query: () => Promise.resolve([]),
        reload: () => Promise.resolve(),
    },
};
global.chrome = global.browser;
global.self = global;

console.log('=== e2e: scripting-manager.js registerContentScripts() must not wipe unrelated ids ===\n');

let failures = 0;
function check(name, cond) {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}`); }
}

const modUrl = `file://${path.join(ROOT, 'js/core/scripting-manager.js')}?t=${Date.now()}`;
const { registerContentScripts } = await import(modUrl);

// Register an id the orchestrator does NOT own, exactly as a foreign
// caller (a different module, or a future feature) might.
const UNRELATED_ID = 'totally-unrelated-test-script';
await scriptingMock.registerContentScripts([ {
    id: UNRELATED_ID,
    js: [ '/js/scripting/does-not-matter.js' ],
    matches: [ 'https://example.com/*' ],
} ]);
check('unrelated id registered before running the orchestrator', registered.has(UNRELATED_ID));

let threw = null;
try {
    await registerContentScripts();
} catch (err) {
    threw = err;
}
check('registerContentScripts() completed without throwing', threw === null);
if ( threw ) { console.log(`    ${threw.stack ?? threw.message}`); }

check(
    'unrelated id SURVIVES the orchestrator run (the actual proof no blanket wipe remains)',
    registered.has(UNRELATED_ID)
);

const idsAfter = [ ...registered.keys() ];
const realIds = idsAfter.filter(id => id !== UNRELATED_ID);
check(
    'orchestrator did real registration work, not a silently-swallowed no-op (found other registered ids besides the unrelated one)',
    realIds.length > 0
);
console.log(`    ids after run: ${idsAfter.join(', ')}`);

console.log(`\n${failures === 0 ? 'PASS' : 'FAIL'}: e2e scripting no-blanket-wipe check (${failures} failure(s))`);
process.exit(failures === 0 ? 0 : 1);

#!/usr/bin/env node
// check-scripting-site-mode-gating.mjs — guards against the recurring bug
// class documented in ARCHITECTURE.md's "HARD CONSTRAINT — every
// browser.scripting call site must be site-mode-gated": a call into the
// browser.scripting API that runs with no awareness of per-site filtering
// mode at all, so turning a site OFF (or a temp-disable pause) stops DNR
// network blocking but leaves that call's own JS/CSS injection running
// anyway. Found and fixed FOUR separate times in this codebase before this
// check existed — see CHANGELOG.md.
//
// This is a static, heuristic scan, not a control-flow analyzer — it
// cannot prove a call site is correctly gated, only that someone looked at
// it and recorded why it's safe (or isn't). Every real call site in the
// codebase must appear in the CLASSIFIED map below with one of three
// justifications:
//
//   'gated'      — the enclosing function itself consults site-mode state
//                   (buildSiteModeMatchScope() / getFilteringMode()) before
//                   this call.
//   'downstream' — this call only ever runs because an already-gated
//                   content script (registered with site-mode-aware
//                   matches/excludeMatches) asked for it; the gating
//                   happened one level up, at registration time.
//   'exempt'     — deliberately outside site-mode's scope: a user-invoked,
//                   host-scoped tool (e.g. Privacy Inspector's probe) that
//                   isn't passive ambient filtering, or a call that isn't
//                   filtering-related at all (e.g. a one-off hostname
//                   probe).
//
// A call site found in the scan but NOT in CLASSIFIED fails the check —
// new code must be triaged into one of the three categories (and, for
// 'gated', actually gated) before it can ship. A CLASSIFIED entry no
// longer found in the scan is reported as stale (warning only, so a
// refactor that removes/renames a call site doesn't need this file edited
// in the same breath — but it should be cleaned up).
//
// Usage: node tools/check-scripting-site-mode-gating.mjs   (also runs as
// step 14 of `npm run check` / tools/complete-check.mjs)

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const ROOT = path.resolve(import.meta.dirname, '..');
// ENTRYPOINT GUARD (added alongside the CLASSIFIED export above): the
// scan-and-report logic at the bottom of this file must only run when
// this script is executed directly (`node tools/check-scripting-site-
// mode-gating.mjs`), not when it's imported purely to reuse CLASSIFIED
// (see check-scripting-site-mode-gating-semgrep.mjs) — without this,
// importing the map would also trigger a full second scan + its own
// process.exit() as a side effect of the import itself.
const isMainModule = process.argv[1] !== undefined &&
    fileURLToPath(import.meta.url) === path.resolve(process.argv[1]);

// file (relative to ROOT) -> Map<enclosingFunctionName, { status, why }>
// EXPORTED (added when wiring in the semgrep cross-check, see
// check-scripting-site-mode-gating-semgrep.mjs) so the AST-based
// cross-check consumes the exact same classification data — one source
// of domain knowledge, not two independently-maintained copies (B15).
export const CLASSIFIED = new Map([
    [ 'js/core/scripting-manager.js', new Map([
        [ 'registerScriptletContentScriptsImpl', {
            status: 'gated',
            why: 'built from buildSiteModeMatchScope() (siteModeMatches/siteModeExcludes) earlier in this same function',
        } ],
        [ 'registerCosmeticContentScriptsImpl', {
            status: 'gated',
            why: 'built from buildSiteModeMatchScope() (siteModeMatches/siteModeExcludes) earlier in this same function',
        } ],
        [ 'registerCookieClickerContentScriptsImpl', {
            status: 'gated',
            why: 'built from buildSiteModeMatchScope() (siteModeMatches/siteModeExcludes) earlier in this same function, same as registerScriptletContentScriptsImpl/registerCosmeticContentScriptsImpl just above',
        } ],
        [ 'registerCookieClickerAutoDenyContentScriptsImpl', {
            status: 'gated',
            why: '"Never consent" auto-deny (added v8.2.0, ubol-autodeny MAIN-world group) — built from buildSiteModeMatchScope() (siteModeMatches/siteModeExcludes) earlier in this same function, identical shape to registerCookieClickerContentScriptsImpl just above. This entry closes the gap CHANGELOG.md\'s 8.2.0/8.2.1 entries flagged as unresolved (this check tool was unavailable when that feature shipped) — verified against the real v8.3.0 source, not assumed.',
        } ],
        [ 'registerSecurityContentScriptsImpl', {
            status: 'gated',
            why: 'directives come from prepareSecurityScriptletDirectives() (compiled-filters.js), which itself calls buildSiteModeMatchScope()',
        } ],
        [ 'registerCustomFiltersDirective', {
            status: 'gated',
            why: 'Porting item 1 (v9.4.9): this was previously the browser.scripting.registerContentScripts(toAdd) call site inside register() itself, classified there as \'register\' — moved here as its own function so the css-user directive gets its own existing-vs-wanted diff instead of relying on register()\'s blanket wipe. Same gating as before: the directive parameter comes from registerCustomFilters(context), which applies context.filteringModeDetails (none/basic) before returning anything.',
        } ],
        [ 'registerContentScriptsSafely', {
            status: 'downstream',
            why: 'generic pass-through; directives are supplied by the caller — see privacy-inspector.js registerProbe(), classified as exempt below',
        } ],
    ] ) ],
    [ 'js/core/filter-manager.js', new Map([
        [ 'startCustomFilters', {
            status: 'downstream',
            why: 'only invoked by css-user.js, which is only ever registered on non-OFF hostnames by registerCustomFilters() (see its own BUG FIXED comment for the historical version of this exact gap)',
        } ],
        [ 'terminateCustomFilters', {
            status: 'exempt',
            why: 'cleanup/teardown action (removes previously-injected CSS) — safe to run unconditionally regardless of current site mode',
        } ],
        [ 'injectCustomFilters', {
            status: 'gated',
            why: 'collectMatchingFilterEntries(index, hostname) already scopes to matching stored rules for this hostname; additionally downstream of registerCustomFilters() gating css-user.js registration itself',
        } ],
    ] ) ],
    [ 'js/core/custom-scriptlets.js', new Map([
        [ 'injectCustomScriptletsForFrame', {
            status: 'gated',
            why: 'getFilteringMode(hostname) === MODE_NONE guard at the top of this function — see CHANGELOG.md, the 4th occurrence of this bug class',
        } ],
    ] ) ],
    [ 'js/workflow/filter-routes.js', new Map([
        [ 'handleInjectCSSProceduralAPI', {
            status: 'downstream',
            why: 'responds to a message sent BY an already-injected content script (loaded via injectCustomFilters(), itself downstream of registerCustomFilters() gating) — moved here from background.js during the filter-manager.js route extraction, same classification carried over unchanged',
        } ],
    ] ) ],
    [ 'js/workflow/cookie-clicker-routes.js', new Map([
        [ 'handleCookieClickerAutoDenyStart', {
            status: 'gated',
            why: 'immediate-apply executeScript for the tab that triggered "Never consent" — FIXED this pass (previously unclassified/ungated, a real instance of the HARD CONSTRAINT bug class: the future-load registration was already gated via buildSiteModeMatchScope() inside startAutoDeny(), but this immediate-tab call was not). Now guarded with getFilteringMode(hostname) === MODE_NONE, same pattern as custom-scriptlets.js injectCustomScriptletsForFrame() and privacy-inspector.js recordPrivacyInspectorEvent() (sender.url || sender.tab?.url for the frame URL, never tabId alone).',
        } ],
        [ 'handleCookieClickerLaunchPicker', {
            status: 'exempt',
            why: 'deliberate, single-click, user-initiated detection + picker launch (button in the popup) — moved here from popup.js\'s own #gotoCookieClicker click handler in 8.2.17 (see this function\'s own file-header note). The pre-existing popup.js picker launches (#gotoPicker for the cosmetic element picker, and the original #gotoCookieClicker before the 8.2.17 move) were never site-mode-gated either — established project convention for manual, one-shot authoring/detection tools the user explicitly triggers on the page they are already looking at, as distinct from automatic per-navigation injection.',
        } ],
        [ 'handleWorryFreeLaunchPicker', {
            status: 'exempt',
            why: 'same shape/reasoning as handleCookieClickerLaunchPicker just above, deliberately (v8.3.19) — a deliberate, single-click, user-initiated overlay launch (popup\'s #gotoWorryFree handler), not automatic per-navigation injection. Shows a duration-choice dialog only; the actual auto-deny session start (the thing that has real, ongoing site-facing effects) only happens once the person picks a duration inside that dialog, via the already-gated startAutoDeny()/handleCookieClickerAutoDenyStart() path above — this launch step itself has no filtering effect of its own to gate.',
        } ],
    ] ) ],
    [ 'js/workflow/background.js', new Map([
        [ 'onPermissionGrantedThruBrowser', {
            status: 'exempt',
            why: 'not a filtering action — probes the active tab\'s hostname to decide whether to auto-reload after a permission grant',
        } ],
        [ 'onContextMenuClicked', {
            status: 'exempt',
            why: 'RENAMED from onContextMenuPickerClicked (v8.6.3) — this function is now the single switch-based router for all 4 right-click menu items (Cosmetic element picker, Cookie consent clicker, Dynamic DNR filtering, Privacy Inspector), not just the picker; only the PICKER case still contains a browser.scripting call, same shape/reasoning as cookie-clicker-routes.js\'s handleCookieClickerLaunchPicker/handleWorryFreeLaunchPicker (v8.5.6) — a deliberate, single-click, user-initiated cosmetic element picker launch, this time from the right-click context menu rather than the popup\'s own #gotoPicker button, but the exact same underlying tool/files/target shape either way. Manual, one-shot authoring tool the user explicitly triggers on the page they are already looking at, as distinct from automatic per-navigation injection — same established convention popup.js\'s own #gotoPicker has never been site-mode-gated under either. The other 3 menu items added in this same pass (Cookie consent clicker, Dynamic DNR filtering, Privacy Inspector) call handleCookieClickerLaunchPicker()/handleStartMatrix()/handleStartPrivacyInspector() directly — no new browser.scripting call site, so nothing further to classify here for them.',
        } ],
    ] ) ],
]);

// Matches `browser.scripting.<method>(` or `chrome.scripting.<method>(` —
// the two aliases this codebase uses interchangeably (see ext-compat.js).
const CALL_RE = /\b(?:browser|chrome)\.scripting\.(registerContentScripts|updateContentScripts|executeScript)\s*\(/;

// Matches the nearest enclosing function declaration this codebase's style
// actually uses: `function name(`, `async function name(`, `export
// [async] function name(`, or `<namespace>.<name> = async function name(`
// (the registerContentScripts.register = ... convention in
// scripting-manager.js — see that file's own comment on why).
const FUNC_DECL_RE = /(?:^|\s)(?:export\s+)?(?:async\s+)?function\s+([A-Za-z0-9_$]+)\s*\(/;

function listFiles(dir, exclude) {
    const out = [];
    for ( const entry of fs.readdirSync(dir, { withFileTypes: true }) ) {
        if ( exclude.includes(entry.name) ) { continue; }
        const full = path.join(dir, entry.name);
        if ( entry.isDirectory() ) { out.push(...listFiles(full, exclude)); }
        else if ( entry.name.endsWith('.js') || entry.name.endsWith('.mjs') ) { out.push(full); }
    }
    return out;
}

// EXPORTED alongside CLASSIFIED (see that export's own comment) — the
// semgrep cross-check dynamically re-derives the regex-based resolution
// for a given (file, line) rather than hardcoding a location string, so
// its one documented message-interpolation-quirk fallback (see that
// file's own KNOWN_MESSAGE_INTERPOLATION_QUIRKS comment) stays correct
// across line-number shifts from ordinary edits, instead of needing
// manual updates every time this file's line count changes.
export function enclosingFunctionName(lines, callLineIndex) {
    for ( let i = callLineIndex; i >= 0; i-- ) {
        const m = FUNC_DECL_RE.exec(lines[i]);
        if ( m ) { return m[1]; }
    }
    return null;
}

const jsDir = path.join(ROOT, 'js');

// ── Everything below only runs when this file is executed directly —
// see the ENTRYPOINT GUARD comment above CLASSIFIED's export for why. ──
if ( isMainModule ) {
    const files = listFiles(jsDir, [ 'lib', 'generated' ]);

    const found = []; // { relPath, func, lineNo }
    for ( const file of files ) {
        const relPath = path.relative(ROOT, file).split(path.sep).join('/');
        const text = fs.readFileSync(file, 'utf8');
        const lines = text.split('\n');
        lines.forEach((line, i) => {
            const trimmed = line.trim();
            // Skip comment lines — full-line // or block-comment-continuation
            // lines (the doc comments in custom-scriptlets.js/scripting-
            // manager.js/picker.js that merely MENTION the API by name are not
            // call sites). Not a full comment-stripper — a call site that's
            // itself commented out on a trailing-comment line would still slip
            // through, but this codebase's style never does that.
            if ( trimmed.startsWith('//') || trimmed.startsWith('*') || trimmed.startsWith('/*') ) { return; }
            if ( CALL_RE.test(line) === false ) { return; }
            const func = enclosingFunctionName(lines, i);
            found.push({ relPath, func, lineNo: i + 1 });
        });
    }

    let failures = 0;
    const seen = new Set(); // relPath::func already reported, so N calls in one function print once

    console.log(`Scanned ${files.length} files under js/ — found ${found.length} browser.scripting call site(s).\n`);

    for ( const { relPath, func, lineNo } of found ) {
        const key = `${relPath}::${func}`;
        if ( seen.has(key) ) { continue; }
        seen.add(key);

        const fileMap = CLASSIFIED.get(relPath);
        const entry = func !== null ? fileMap?.get(func) : undefined;

        if ( entry === undefined ) {
            failures++;
            console.log(`✗ UNCLASSIFIED: ${relPath}:${lineNo} — inside ${func ? `function "${func}"` : '(no enclosing function found — check by hand)'}`);
            console.log(`    This call site is not in CLASSIFIED. Either gate it using getFilteringMode()/`);
            console.log(`    buildSiteModeMatchScope() (see ARCHITECTURE.md's HARD CONSTRAINT), or add it to`);
            console.log(`    CLASSIFIED here with a 'gated'/'downstream'/'exempt' justification.`);
            continue;
        }
        console.log(`✓ ${entry.status.padEnd(10)} ${relPath}::${func}`);
        console.log(`    ${entry.why}`);
    }

    // Stale-entry check — informational, does not fail the run (see file header).
    let stale = 0;
    for ( const [ relPath, fileMap ] of CLASSIFIED ) {
        for ( const func of fileMap.keys() ) {
            if ( seen.has(`${relPath}::${func}`) ) { continue; }
            stale++;
            console.log(`\n⚠ STALE CLASSIFIED entry (no longer found by the scan): ${relPath}::${func} — remove or investigate why it disappeared.`);
        }
    }

    console.log('');
    if ( failures > 0 ) {
        console.log(`${failures} unclassified browser.scripting call site(s) — do not zip until triaged.`);
        process.exit(1);
    }
    console.log(`All browser.scripting call sites are classified.${stale > 0 ? ` (${stale} stale entries, see warnings above)` : ''}`);
}

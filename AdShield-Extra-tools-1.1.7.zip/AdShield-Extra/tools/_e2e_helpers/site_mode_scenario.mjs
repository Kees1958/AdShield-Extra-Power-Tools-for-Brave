// Runs ONE scenario (sequential or bulk) for e2e_site_mode_bulk.mjs, in
// its own fresh Node process — required because js/data/ext.js captures
// the browser/chrome global ONCE at first import (a plain relative
// import, no cache-busting query), so two scenarios can't safely share
// one process the way most of this project's other e2e tests do.
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '../..');
const scenario = process.argv[2]; // 'sequential' | 'bulk'

const store = { local: {}, session: {} };
let localSetCalls = 0;
let sessionSetCalls = 0;
let dnrUpdateCalls = 0;
function makeStorageArea(area, counterIncr) {
    return {
        get: (key) => {
            if ( key === undefined || key === null ) { return Promise.resolve({ ...store[area] }); }
            if ( typeof key === 'string' ) { return Promise.resolve({ [key]: store[area][key] }); }
            const out = {};
            for ( const k of Object.keys(key) ) { out[k] = store[area][k] ?? key[k]; }
            return Promise.resolve(out);
        },
        set: (obj) => { counterIncr(); Object.assign(store[area], obj); return Promise.resolve(); },
        remove: (keys) => { for ( const k of [].concat(keys) ) { delete store[area][k]; } return Promise.resolve(); },
    };
}
global.browser = {
    storage: {
        local: makeStorageArea('local', () => localSetCalls++),
        session: makeStorageArea('session', () => sessionSetCalls++),
        onChanged: { addListener(){} },
    },
    declarativeNetRequest: {
        getDynamicRules: () => Promise.resolve([]),
        updateDynamicRules: () => { dnrUpdateCalls++; return Promise.resolve(); },
        getSessionRules: () => Promise.resolve([]),
        updateSessionRules: () => Promise.resolve(),
    },
    permissions: {
        getAll: () => Promise.resolve({ origins: [ '<all_urls>' ], permissions: [] }),
        onAdded: { addListener(){} },
        onRemoved: { addListener(){} },
    },
    runtime: { getURL: p => `chrome-extension://test/${p}`, id: 'test', onMessage: { addListener(){} } },
    tabs: { TAB_ID_NONE: -1, query: () => Promise.resolve([]) },
};
global.chrome = global.browser;
global.self = global;

const { setFilteringMode, setFilteringModesBulk, MODE_NONE } = await import(path.join(ROOT, 'js/core/mode-manager.js'));

const testHostnames = [ 'example.com', 'sub.example.com', 'other.test', 'another.example' ];

if ( scenario === 'sequential' ) {
    for ( const hostname of testHostnames ) {
        await setFilteringMode(hostname, MODE_NONE);
    }
} else if ( scenario === 'bulk' ) {
    await setFilteringModesBulk(testHostnames.map(h => [ h, MODE_NONE ]));
} else {
    throw new Error(`unknown scenario: ${scenario}`);
}

process.stdout.write(JSON.stringify({
    counts: { localSetCalls, sessionSetCalls, dnrUpdateCalls },
    finalState: store.local.filteringModeDetails ?? null,
}));
process.exit(0);

// tools/check-autoconsent-cmp-consistency.mjs — rules.json ↔
// eval-snippets.js ↔ the generated autodeny bundle stay in sync, plus
// the hash trip-wire that catches an un-rebuilt bundle after
// eval-snippets.js changes. Ported from tools/self-test.mjs's checks
// [3/6] and [4/6] (see CHANGELOG — self-test.mjs retired; see
// check-json-syntax.mjs's own header for why).
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

let failures = 0;

console.log('=== CMP data consistency — rules.json ↔ eval-snippets.js ↔ generated bundle ===');

const rulesDoc = JSON.parse(fs.readFileSync(path.join(ROOT, 'vendor/autoconsent/rules/rules.json'), 'utf8'));
const actionableRules = rulesDoc.rules.filter(r => r.action !== null);

const evalSrc = fs.readFileSync(path.join(ROOT, 'vendor/autoconsent/eval-snippets.js'), 'utf8');
const missingFns = [];
for ( const rule of actionableRules ) {
    if ( evalSrc.includes(`${rule.action}:`) === false ) { missingFns.push(rule.action); }
}
if ( missingFns.length === 0 ) {
    console.log(`PASS: every one of ${actionableRules.length} actionable rules has a matching function in eval-snippets.js`);
} else {
    failures++;
    console.log(`FAIL: missing eval-snippets.js functions: ${JSON.stringify(missingFns)}`);
}

const bundleSrc = fs.readFileSync(path.join(ROOT, 'js/scripting/autodeny-snippets.generated.js'), 'utf8');
// [A-Z0-9_]+ (not [A-Z_]+) — digit-inclusion fix carried over from
// build-autodeny-bundle.mjs's own header regex (EVAL_TYPO3COOKIEMAN_REJECT/
// EVAL_STCMPV2_REJECT both contain a digit).
const bundleFnCount = [ ...bundleSrc.matchAll(/EVAL_[A-Z0-9_]+:\s*function/g) ].length;
if ( bundleFnCount === actionableRules.length ) {
    console.log(`PASS: generated bundle contains exactly ${bundleFnCount} action functions, matching rules.json's actionable count`);
} else {
    failures++;
    console.log(`FAIL: generated bundle function count mismatch — bundle has ${bundleFnCount}, rules.json expects ${actionableRules.length}. Bundle may be stale: run node tools/build-autodeny-bundle.mjs`);
}

console.log('\n=== Hash trip-wire — vendor/autoconsent/eval-snippets.js matches the recorded hash in build-autodeny-bundle.mjs ===');
try {
    execFileSync(process.execPath, [ 'tools/build-autodeny-bundle.mjs' ], { cwd: ROOT, stdio: 'pipe' });
    console.log('PASS: build-autodeny-bundle.mjs ran clean — hash trip-wire did not fire.');
} catch (e) {
    failures++;
    console.log('FAIL: build-autodeny-bundle.mjs hash trip-wire fired (or another build error).');
    console.log((e.stderr?.toString() ?? '').split('\n').slice(0, 5).join('\n'));
}

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} CMP data-consistency check(s) failed.`);
    process.exitCode = 1;
} else {
    console.log('PASS: all CMP data-consistency checks clean.');
}

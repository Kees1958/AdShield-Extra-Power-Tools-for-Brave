// New check (this session): dead-export detection. Every function/const
// exported from js/core/*.js should be imported by at least one other
// file — an export nobody imports is either orphaned code or a wiring
// mistake (a function that should be used somewhere but isn't). Scoped
// to js/core/ specifically (the shared logic layer) rather than the
// whole tree — page-context files (dashboard/, matrix/, popup/) export
// nothing by convention (they're entry points, not libraries), so
// checking them would just be noise.
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

function listFiles(dir, exts) {
    const out = [];
    for ( const entry of fs.readdirSync(dir, { withFileTypes: true }) ) {
        const full = path.join(dir, entry.name);
        if ( entry.isDirectory() ) { out.push(...listFiles(full, exts)); }
        else if ( exts.some(e => entry.name.endsWith(e)) ) { out.push(full); }
    }
    return out;
}

const coreFiles = listFiles(path.join(ROOT, 'js/core'), [ '.js', '.mjs' ]);
const allJsFiles = listFiles(path.join(ROOT), [ '.js', '.mjs' ])
    .filter(f => !f.includes('/node_modules/') && !f.includes('/lib/') && !f.includes('/tools/'));

// Combined source of every OTHER file, to search for import references —
// excludes each core file's own content when checking itself (a function
// calling a sibling in the same file isn't an "import").
const allSourcesCombined = allJsFiles.map(f => {
    const content = fs.readFileSync(f, 'utf8');
    return { file: f, content };
});

console.log('=== Dead-export check: js/core/*.js ===');

const exportPattern = /export\s+(?:async\s+)?function\s+(\w+)|export\s+const\s+(\w+)/g;
let checkedCount = 0;
const deadExports = [];

for ( const coreFile of coreFiles ) {
    const src = fs.readFileSync(coreFile, 'utf8');
    for ( const m of src.matchAll(exportPattern) ) {
        const name = m[1] ?? m[2];
        if ( !name ) { continue; }
        checkedCount++;
        const usedElsewhere = allSourcesCombined.some(({ file, content }) => {
            if ( file === coreFile ) { return false; }
            // A real import, not just the name appearing incidentally in
            // a comment or string — require it inside an import{...} block
            // or as a namespace-qualified call, both realistic enough for
            // this codebase's own consistent ES-module import style.
            return new RegExp(`\\b${name}\\b`).test(content) && content.includes('from');
        });
        if ( !usedElsewhere ) {
            deadExports.push({ name, file: path.relative(ROOT, coreFile) });
        }
    }
}

console.log(`Checked ${checkedCount} exports across ${coreFiles.length} files in js/core/.`);
if ( deadExports.length > 0 ) {
    for ( const { name, file } of deadExports ) {
        console.log(`FLAG (unused outside its own file — verify by hand, this check has false-positive risk): ${name} (${file})`);
    }
} else {
    console.log('PASS: every export from js/core/*.js is referenced by at least one other file.');
}
console.log('');
// Informational only, not a hard failure — see the false-positive caveat
// in the FLAG message above (e.g. a name reused as a common word
// elsewhere, or genuinely-intentional unused public API surface).
process.exitCode = 0;
